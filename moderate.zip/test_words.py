# -*- coding: utf-8 -*-
import re, string, unicodedata
import os
import sys
reload(sys)  # Reload does the trick!
sys.setdefaultencoding('UTF8')

def remove_punctuation ( s ):
    return ''.join((c for c in unicodedata.normalize('NFD', s) if unicodedata.category(c) != 'Mn'))



while True:
	from moderate import *
	text=str(raw_input(">>"))
	if text=="cls" or text=="\xe2":
		os.system("cls")
		continue
	text=remove_punctuation(text.decode('utf-8')).lower()
	for bad_word in bad_words:
		regexp=(bad_word.replace("\n",""))
		if regexp!="":
			match = re.search(regexp,text)
			if match:
				print regexp,
	print 