from utils.settings import *
from utils.info import *
from utils.chessUtils import *
from utils.user import *
# create_settings(254365854)
# print get_settings(254365854)
# print update_settings(254365854,theme="green",engine="jazz")

# print is_ready_info(254365854)
# print white_info(254365854)
# 
# print settings_exist(254365854)
# create_pgn_buffer(254365854)
# update_pgn_buffer(254365854,"Nf3")
# print get_last_from_pgn(47917685)

# update_info(47917685,game_type="1")
# print is_ready_info()

print create_user(47917685,"Antonio","Aguilar")
print get_user_info(47917685)['name']
