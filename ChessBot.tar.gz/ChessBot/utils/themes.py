# text_color # lightcolor # darkcolor

THEMES={
	"beige":["#0B0B0B","#F0D9B5","#B58863"],
	"blue":["#000000","#F5F5F5","#05A0C9"],
	"gray":["#111111","#fff","#727272"],
	"green":["#000000","#E7E7C6","#4AA54A"],
	"ocre":["#000000","#F3ECD2","#AB5254"],
	"pink":["#000000","#F5F5F5","#E23380"],
	"red":["#000000","#F5F5F5","#E6624E"],
	"wood":["#B58D58","#FECE9E","#D18B46"],
}