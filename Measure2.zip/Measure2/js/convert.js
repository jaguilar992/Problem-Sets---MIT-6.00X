function getNumer(i) {
	var a=$("#numer_"+i).val();
	return a;
}

function getDenom(i) {
	var b=$("#denom_"+i).val();
	return b;	
}

function convert(){
	file_name=$("#categoryName").val(); 
	var selected=$(".selected")[0].id;
	selected=selected.split("li")[1];
	var VALUE=$("#li"+selected+" .val").html();

	var DEFAULT_UNIT=$("#default").val();
	var TYPE = $("#type").val();
	var COUNT = $("#count").val();

	//IF type=="factor"
	var DEFAULT_VALUE=VALUE*(getDenom(selected)/getNumer(selected));
	if (VALUE!=0) {
		for (var i = 0; i < COUNT; i++) {
			if (i!=DEFAULT_UNIT & i!=selected) {
					var convert=DEFAULT_VALUE*(getNumer(i)/getDenom(i));
					$("#li"+i+" .val").html(formatNums(convert));
			}
		}
		if (selected!=DEFAULT_UNIT) {
			$("#li"+DEFAULT_UNIT+" .val").html(formatNums(DEFAULT_VALUE));
		}else{
			$("#li"+DEFAULT_UNIT+" .val").html(DEFAULT_VALUE);

		}
	
	}else{
		$(".val").html(0);
	}
}


function formatNums(num){
	if (num<1e-6) {
		num=num.toExponential(SELECTED_PREC);
	}else if(num>1e-6 & num<1){
		num=num.toFixed(6);
		num=deletZeros(num);
	}else if(num>=1 & num<1e7){
		num=num.toFixed(SELECTED_PREC);
		num=deletZeros(num);
	}else if(num>=1e7){
		num=num.toExponential(SELECTED_PREC);
	}
	return num;
}



function deletZeros(num){
	if(num - Math.floor(num) == 0){
		num=parseFloat(num);
		num=num.toFixed(0);
		// console.log(num);
	}

	// return parseInt(num);
	return separate(num);
}



function separate(valor) {
    var nums = new Array();
    var simb = " "; //Éste es el separador
    valor = valor.toString();
    valor = valor.replace(/\D/g, ".");   //Ésta expresión regular solo permitira ingresar números
    nums = valor.split(""); //Se vacia el valor en un arreglo
    var long = nums.length - 1; // Se saca la longitud del arreglo
    var patron = 3; //Indica cada cuanto se ponen las comas
    var prox = 2; // Indica en que lugar se debe insertar la siguiente coma
    var res = "";
 
    while (long > prox) {
        nums.splice((long - prox),0,simb); //Se agrega la coma
        prox += patron; //Se incrementa la posición próxima para colocar la coma
    }
 
    for (var i = 0; i <= nums.length-1; i++) {
        res += nums[i]; //Se crea la nueva cadena para devolver el valor formateado
    }
 
    return res;
}