function get_numer(i) {
	var a=$("#numer_"+i).val();
	return parseFloat(a);
}

function get_denom(i) {
	var b=$("#denom_"+i).val();
	return b;	
}

function get_intern(i) {
	var a=$("#intern_"+i).val();
	return parseFloat(a);
}

function get_expo(i) {
	var a=$("#expo_"+i).val();
	// 
	return parseFloat(a);
}

function get_extern(i) {
	var a=$("#extern_"+i).val();
	return parseFloat(a);
}



//CARGAR FACTORES CATEGORIA
function makeFactors(json){
	$("body").append('<div id="factors"></div>');
	var COUNT=Object.keys(json).length-3;
	factors=$("#factors");
	type=json["type"];
	Default=json["default"];

	factors.append('<input type="hidden" id="count">');
	factors.append('<input type="hidden" id="default">');
	factors.append('<input type="hidden" id="selected">');
	factors.append('<input type="hidden" id="type">');

	$("#count").val(COUNT);
	$("#type").val(type);
	$("#selected").val(selected);
	$("#default").val(Default);

	for (var i = 0; i < COUNT; i++) {
		numer=json[i]["numer"];
		denom=json[i]["denom"];
		intern=json[i]["intern"];
		expo=json[i]["expo"];
		extern=json[i]["extern"];

		factors.append('<input type="hidden" id="numer_'+i+'">');
		factors.append('<input type="hidden" id="denom_'+i+'">');
		factors.append('<input type="hidden" id="intern_'+i+'">');
		factors.append('<input type="hidden" id="expo_'+i+'">');
		factors.append('<input type="hidden" id="extern_'+i+'">');
		
		$("#denom_"+i).val(denom);
		$("#numer_"+i).val(numer);
		$("#intern_"+i).val(intern);
		$("#extern_"+i).val(extern);
		$("#expo_"+i).val(expo);

	}
}


function convert(){
	var selected=$(".selected")[0].id;
	selected=selected.split("li")[1];
	var VALUE=$("#li"+selected+" .val").html();

	var DEFAULT_UNIT=$("#default").val();
	var TYPE = $("#type").val();
	var COUNT = $("#count").val();

	var n=get_numer(selected);
	var d=get_denom(selected);
	var intr=get_intern(selected);
	var expo=get_expo(selected);
	var extr=get_extern(selected)
	
	//IF type=="factor"
	var DEFAULT_VALUE=Math.pow((d/n)*(VALUE-extr),1/expo)-intr;
	
		for (var i = 0; i < COUNT; i++) {
				var n2=get_numer(i);
				var d2=get_denom(i);
				var intr2=get_intern(i);
				var expo2=get_expo(i);
				var extr2=get_extern(i)
				var CONVERTED_VALUE=(n2/d2)*Math.pow((DEFAULT_VALUE+intr2),expo2)+extr2;
				$("#li"+i+" .val").html(formatNums(CONVERTED_VALUE));
				console.log(CONVERTED_VALUE);
		}
				console.log("\n");
}

