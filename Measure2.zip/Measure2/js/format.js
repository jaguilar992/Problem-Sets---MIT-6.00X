
function formatNums(num){
	if (Math.abs(num)>0 & Math.abs(num)<1e-6) {
		num=num.toExponential(SELECTED_PREC);
	}else if(Math.abs(num)>1e-6 & Math.abs(num)<1){
		num=num.toFixed(6);
		num=deletZeros(num);
	}else if(Math.abs(num)>=1 & Math.abs(num)<1e7){
		num=num.toFixed(SELECTED_PREC);
		num=deletZeros(num);
	}else if(Math.abs(num)>=1e7){
		num=num.toExponential(SELECTED_PREC);
	}
	return num;
}



function deletZeros(num){
	if(num - Math.floor(num) == 0){
		num=parseFloat(num);
		num=num.toFixed(0);
		// console.log(num);
	}

	// return parseInt(num);
	return separate(num);
}



function separate(valor) {
    var nums = new Array();
    var simb = " "; //Éste es el separador
    valor = valor.toString();
    valor = valor.replace(/\D/g, ".");   //Ésta expresión regular solo permitira ingresar números
    nums = valor.split(""); //Se vacia el valor en un arreglo
    var long = nums.length - 1; // Se saca la longitud del arreglo
    var patron = 3; //Indica cada cuanto se ponen las comas
    var prox = 2; // Indica en que lugar se debe insertar la siguiente coma
    var res = "";
 	
    while (long > prox) {
        nums.splice((long - prox),0,simb); //Se agrega la coma
        prox += patron; //Se incrementa la posición próxima para colocar la coma
    }
 
    for (var i = 0; i <= nums.length-1; i++) {
        res += nums[i]; //Se crea la nueva cadena para devolver el valor formateado
    }
 	
 	if (res[0]=="."){
 		res="-"+res.substr(1,res.length)
 	}

    return res;
}