(function(e){if(typeof define==="function"&&define.amd){define(["jquery","hammerjs"],e)}else if(typeof exports==="object"){e(require("jquery"),require("hammerjs"))}else{e(jQuery,Hammer)}})(function(e,t){function n(n,r){var i=e(n);if(!i.data("hammer")){i.data("hammer",new t(i[0],r))}}e.fn.hammer=function(e){return this.each(function(){n(this,e)})};t.Manager.prototype.emit=function(t){return function(n,r){t.call(this,n,r);e(this.element).trigger({type:n,gesture:r})}}(t.Manager.prototype.emit)})


var area = $("header").hammer();
area.on("tap", function(a) {
        $('html, body').animate({scrollTop: 0}, 'slow');
});