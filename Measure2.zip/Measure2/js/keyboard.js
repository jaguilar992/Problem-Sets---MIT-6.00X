function defineEvent(key){
	var key=key.currentTarget.id;
	// console.log(key);
	var type=key.split('_')[0];
	var arg=key.split('_')[1];
	if (type=="nb") {
		do_nb(type,arg);
	}else{
		do_op(type,arg);
	}
}


var disableKey=function(elementID){
      $("#"+elementID).off('click');
      return true;
};

var resetKey=function () {
     // $("#"+elementID).on('click',defineEvent);	
	$(".key").on('click',defineEvent);
	return true;
}


// $(function(){
//     $("#div-test-id").click(div_click_escape);
//     $("#div-test-id").mousedown(div_click_escape);
//     $("#div-test-id").mouseup(div_click_escape);
// }

function do_nb(type, arg){
	if ($("#screen p").html()=="0") {
		$("#screen p").html(arg);
	}else{
		$("#screen p").append(arg);
	}
	updateValues();
}

function do_op(type, arg){
	// EVENT: Point
	if (arg=="pt" && $("#screen p").html().indexOf('.')==-1 ) {
		$("#screen p").append(".");	
		disableKey("nb_pt");
	}//END
	// EVENT: DELETE
	if (arg=="del") {
		var string=$("#screen p").html();
		var newstr=string.substring(0,string.length-1);
		var newstr2=string.substring(0,string.length-2);
		if (string.length==1) {
			$("#screen p").html("0");
		}else{
			$("#screen p").html(newstr);
			if (newstr[newstr.length-1]==".") {
				$("#screen p").html(newstr2);
				
			}
		}
		updateValues();
	}//END

	//EVENT AC
	if (arg=="clear") {
		// resetKey();
		$("#op_eq").attr("onclick","byeKeys()");
		$("#screen span").html("");
		$("#screen p").html("0");
		updateValues();
	}//END

	//EVENT SQRT
	if (arg=="sqrt") {
		var ToCalc=$("#entry").val();
		var calculation =Math.sqrt(ToCalc);
		cipher=calculation.toFixed().length;
		if (calculation-Math.floor(calculation)!=0) {
			$("#screen p").html(calculation.toFixed(10-cipher));
		}else{
			$("#screen p").html(calculation);
		}
		updateValues();
		// disableKey("op_del");
	}//END


	//EVENT SUM, DIF, MULT, DIVI
	if (arg=="sum" || arg=="dif" || arg=="mult" || arg=="div") {
		$("#op_eq").attr("onclick","finishCalc()");

		var sign={"sum":"+","dif":"-","mult":"×", "div":"÷"};
		$("#screen span").html(sign[arg]);
		$("#screen span").addClass("txt-"+color);
		$("#operator").val(arg);
		var ToCalc=$("#entry").val();
		$("#m1").val(ToCalc);
		$("#screen p").html("0");
		$("#entry").val("0");
		
	}
}

function updateValues(){
	$("#entry").val($("#screen p").html());
	$(".selected .val").html($("#entry").val());
	convert();
}

function finishCalc(){
	$("#op_eq").attr("onclick","byeKeys()");
	$("#screen span").html("");
	var operator=$("#operator").val();
	var m1=$("#m1").val();
	var m2=$("#entry").val();
	
	if (operator=="sum") {
		var resp=parseFloat(m1)+parseFloat(m2);
	}else if (operator=="dif"){
		var resp=m1-m2;
	}else if (operator=="mult"){
		var resp=m1*m2;
	}else if (operator=="div"){
		var resp=m1/m2;
		if (isNaN(resp) || isInfinite(resp)) {
			$("#screen p").html("E");
			$(".val").val("Error");
			return 0;
		}
	}
	resp=parseFloat(resp);
	cipher=resp.toFixed().length;
	if (resp-Math.floor(resp)!=0) {
		$("#screen p").html(resp.toFixed(10-cipher));
	}else{
		$("#screen p").html(resp);
	}
	updateValues();
}


function isInfinite(n) {
  return n === n/0;
}