////////////////////////////////////////////   Funciones de inicio de app
var color="sky";
var HEADER_H=0.19; //percentaje off window
var LI_H =0.9; // percentaje of Header
var SELECTED_PREC =2; // percentaje of Header
window.onload=function(){
	font_size();
	userSettings();
};
function font_size(){
	var set = ($( window ).height());
	var font= set*(14/640);
	$("body").css({
		"font-size": font
	});
}
function userSettings(){
	header(color);
	corpus(color);
}
function header(color){
	var set = $( window ).width()*HEADER_H;
	$("#header, #nav ul").addClass("bg-"+color);
	$("#header").height(set);
	$("#appName").css({"line-height": set+"px"});
}
function corpus(){
	var top = ($( window ).width())*HEADER_H;
	var set = ($( window ).height())-top;
	$("#corpus").height(set);
	$("#corpus").width($(window).width());
	$("#corpus").css({
		"padding-top":top
	});
	$(".category").height($("#header").height()*LI_H);
	$(".category p").height($("#header").height()*LI_H);
	$(".category p").css({"line-height":$("#header").height()*LI_H+"px"});
}



//----------------------------Funcionamiento LISTO-----------------------------------------
$(document).ready(function(){
	// CLICK
	$("#appName").click(function(){scroll()});
	$("#appMenu #menu").click(function(){
		// alert("aSome");
	});
	$("#appSort #sort").click(function(){
		// alert("aSome");
	});
	// HOVER
	$("#appMenu #menu").hover(function(){
		$("#appMenu #menu").attr("src","img/menu2.png");
	},function() {
	    $("#appMenu #menu").attr("src","img/menu.png");
	  });
	$("#appSort #sort").hover(function(){
		$("#appSort img").attr("src","img/sort2.png");
	},function() {
	    $("#appSort img").attr("src","img/sort.png");
	});

	$("#entry").val(0);


});



function scroll(){
	$('html, body').animate({scrollTop:0}, 1000);
}