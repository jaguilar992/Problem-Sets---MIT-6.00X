
////////////////////////////////////////////   Funciones de inicio de app
var HEADER_H=0.19; //percentaje off window
var LI_H =0.9; // percentaje of Header
var SELECTED_PREC =2; // Precision
var KEYBOARD_H=0.6;

window.onload=function(){
	font_size();
	userSettings();
};
function font_size(){
	var set = ($( window ).height());
	var font= set*(14/640);
	$("body").css({
		"font-size": font
	});
}
function userSettings(){
	header(color);
	corpus(color);
}
function header(color){
	var set = $( window ).width()*HEADER_H;
	$("#header, #nav ul").addClass("bg-"+color);
	$("#header").height(set);
	$("#appName").css({"line-height": set+"px"});
}
function corpus(){
	var top = ($( window ).width())*HEADER_H;
	var set = ($( window ).height())-top;
	$("#corpus").height(set);
	$("#corpus").width($(window).width());
	$("#corpus").css({
		"padding-top":top
	});

	//INDEX CATEGORIES
	$(".category").height($("#header").height()*LI_H);
	$(".category p").height($("#header").height()*LI_H);
	$(".category p").css({"line-height":$("#header").height()*LI_H+"px"});

	//SETTINGS
	var malla= $(window).width()*0.2;
	$(".malla_2").css({
		"height": malla,
		"line-height": malla+"px"
	});
	$(".section .title").css({
		"height":malla/2,
		"line-height":malla/2+"px",
	});
	document.getElementById('opt-'+color).innerHTML="✓";
	
}

function scroll(){
	$('html, body').animate({scrollTop:0}, 500);
}


//----------------------------Funcionamiento LISTO-----------------------------------------
$(document).ready(function(){
	// CLICK
	$("#appName").click(function(){scroll()});
	$("header h1").click(function(){scroll()});
	$("#appMenu #menu").click(function(){
		window.location.href="settings.html"
	});
	// HOVER
	$("#appMenu #menu").hover(function(){
		$("#appMenu #menu").attr("src","img/menu2.png");
	},function() {
	    $("#appMenu #menu").attr("src","img/menu.png");
	  });
	$("#appSort #sort").hover(function(){
		$("#appSort img").attr("src","img/sort2.png");
	},function() {
	    $("#appSort img").attr("src","img/sort.png");
	});

	$("#entry").val(0);


});



