//CARGAR CATEGORIA


function loadUnits(id){
	tint(id);
	setTimeout(function(){
		getBack();
		setHeader(id);
		clearCorpus();
		showKeyButton();
		var cats=["aceleration","angle","area","density","distance","energy","force","mass","power","temperature","time","velocity","volume"];
		$("#categoryName").val(cats[id-1]);
		$.getJSON( "standards/"+cats[id-1]+".json").done(function( json ) {
		  	printUnit(json);
		  	makeFactors(json);
		  	sel=json["selected"];
		  	tint(sel);
		  	$("#li"+sel).addClass("selected");
		  	$(".selected .val").html($("#entry").val())
		  }).fail(function( jqxhr, textStatus, error ) {var err = textStatus + ", " + error;console.log( "Request Failed: " + err );
		});
	},100);
	// clearInterval();
}
// TINTA BG LI#N
function tint(id){
	$("li").css({"background":"none"});
	$("#li"+id).css({"background":"#eaeaea"});
}
// LIMPIAR CUERPO
function clearCorpus(){
	$("#corpus").html("");	
}
// CAMBIO DE HEADER
function setHeader(id){
	var cats=["Aceleración","Ángulo","Área","Densidad","Distancia","Energía","Fuerza","Masa","Potencia","Temperatura","Tiempo","Velocidad","Volumen"];
	$(".grid_8 h1").html(cats[id-1]);
}
// CAMBIAR BOTON, REGRESAR
function getBack(){
	$(".button1 img").attr("src","img/back.png");
	document.getElementById("menu").id="back";
	$("#appMenu #back").hover(function(){
			$("#appMenu img").attr("src","img/back2.png");
	});
	$(".button1 #back").click(function(){
			location.reload();
	});
}
// IMPRESION DE UNIDADES --- LISTADO  (CARGA)
function printUnit (json) {
	// console.log(json);
	$("#corpus").append("<ul id='units'></ul>");
	var count=Object.keys(json).length-3;
	for (var i = 0; i < count; i++) {
		$("#units").append("<li id='li"+i+"' onclick='selectLI("+i+")' class='unit'><p><span class='name'>"+json[i].name+"</span><span class='val' id='val"+i+"'>"+0+"</span><span class='sym'>"+json[i]["symbol"]+"</span></p></li>")
		$("span.sym").addClass("txt-"+color);
		$(".unit").height($("#header").height()*LI_H);
		$(".unit p").height($("#header").height()*LI_H);
		$(".unit p").css({"line-height":$("#header").height()*LI_H+"px"});
	}
}
// MOSTRAR BOTON PARA TECLADO
function showKeyButton(){
	var h = ($( window ).height());
	var w = ($( window ).width());
	$("#corpus").append('<a id="show" onclick="showKeys()"><img src="img/keys.png" alt="keys" width="100%"/></a>');
	$("#show").css({
		"position":"fixed",
		"bottom":"5%",
		"left": w*(0.5-0.15/2),
		"width": w*0.15,
		"height": w*0.15,
		"text-align":"center"
	});
}
var KEYBOARD_H=0.6;
// TECLADO
function showKeys(){
	$.get("js/keys.html", function( keys_txt ) {
    	$("#units").append(keys_txt);
	var h = ($( window ).height());
	var w = ($( window ).width());
	$("#keyboard").css({
		"display":"block",
		"position":"fixed",
		"width": w,
		"height": h*KEYBOARD_H,
		"bottom":-h*KEYBOARD_H,
		"background": "#23202B"
	});
	// screen
	$("#screen p, #screen span").css({
		"line-height": h*KEYBOARD_H*0.20+"px",
	});
	//KEYS SIZE
	$(".key").css({
		"height":h*KEYBOARD_H*0.80*0.20,
		"line-height":h*KEYBOARD_H*0.80*0.20+"px",
	});
	//SCREEN VAL
	$("#screen p").html($("#entry").val());
	//COLOR
	$("#keyboard #operators").addClass("txt-"+color);
	$("#op_eq").addClass("bg-"+color);
	//op_eq default behavior
	$("#op_eq").attr("onclick","byeKeys()");
	//KEYS CLICK
	$(".key").click(function($this) {
		defineEvent($this);
	});
	// LAST STEP
	$("#keyboard").animate({"bottom":"0px"},300);
	}, 'html'); 
}
// OCULTAR TECLADO
function byeKeys(){
	var h = ($( window ).height());
	$(".key").off("click");
	$("#keyboard").animate({"bottom":-h*KEYBOARD_H},100);
}


// CAMBIO DE LI

function selectLI(id){
	tint(id);
	var clear=$(".selected")[0].id;
	$("#"+clear).removeClass("selected");

	$("#li"+id).addClass('selected');
	$(".val").html(0);
	$(".selected .val").html($("#entry").val());
	convert();
}



function makeFactors(json){
	$("body").append('<div id="factors"></div>');
	var COUNT=Object.keys(json).length-3;
	factors=$("#factors");
	type=json["type"];
	Default=json["default"];

	factors.append('<input type="hidden" id="count">');
	factors.append('<input type="hidden" id="default">');
	factors.append('<input type="hidden" id="selected">');
	factors.append('<input type="hidden" id="type">');

	$("#count").val(COUNT);
	$("#type").val(type);
	$("#selected").val(selected);
	$("#default").val(Default);

	for (var i = 0; i < COUNT; i++) {
		numer=json[i]["numer"];
		denom=json[i]["denom"];
		factors.append('<input type="hidden" id="numer_'+i+'">');
		factors.append('<input type="hidden" id="denom_'+i+'">');
		$("#denom_"+i).val(denom);
		$("#numer_"+i).val(numer);

	}
}