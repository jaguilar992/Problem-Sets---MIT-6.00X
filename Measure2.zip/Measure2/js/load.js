
// CAMBIAR BOTON, REGRESAR
function getBack(){
	$(".button1 img").attr("src","img/back.png");
	$(".button2 img").attr("src","img/menu.png");
	document.getElementById("menu").id="back";
	document.getElementById("sort").id="menu";
	$("#appMenu #back").hover(function(){
			$("#appMenu img").attr("src","img/back2.png");
	});

	$("#appSort #menu").hover(function(){
			$("#appSort img").attr("src","img/menu2.png");
	});

	$(".button1 #back").click(function(){
			window.location.href="index.html";
	});

	$(".button2 #menu").click(function(){
		window.location.href="settings.html"
	});
}

// CAMBIO DE HEADER
function setHeader(id){
	
	$(".grid_8 h1").html(CAT_NAME[id]);
}

// LIMPIAR CUERPO
function clearCorpus(){
	$("#corpus").html("");	
}


// MOSTRAR BOTON PARA TECLADO
function showKeyButton(){
	var h = ($( window ).height());
	var w = ($( window ).width());
	$("#corpus").append('<a id="show" onclick="showKeys()"><img src="img/keys.png" alt="keys" width="100%"/></a>');
	$("#show").css({
		"position":"fixed",
		"bottom":"5%",
		"left": w*(0.5-0.15/2),
		"width": w*0.15,
		"height": w*0.15,
		"text-align":"center"
	});
}

// IMPRESION DE UNIDADES --- LISTADO  (CARGA)
function printUnit (json) {
	// console.log(json);
	$("#corpus").append("<ul id='units'></ul>");
	var count=Object.keys(json).length-3;
	for (var i = 0; i < count; i++) {
		$("#units").append("<li id='li"+i+"' onclick='selectLI("+i+")' class='unit'><p><span class='name'>"+json[i].name+"</span><span class='val' id='val"+i+"'>"+0+"</span><span class='sym'>"+json[i]["symbol"]+"</span></p></li>")
		$("span.sym").addClass("txt-"+color);
		$(".unit").height($("#header").height()*LI_H);
		$(".unit p").height($("#header").height()*LI_H);
		$(".unit p").css({"line-height":$("#header").height()*LI_H+"px"});
	}
}


// MakeFactos ha sido movido a convert.js con fines de claridad en el desarrollo


// TINTA BG LI#N
function tint(id){
	$("li").css({"background":"none"});
	$("#li"+id).css({"background":"#eaeaea"});
}

function loadUnits(id){
	tint(id);
	setTimeout(function(){
		getBack();
		setHeader(id);
		clearCorpus();
		showKeyButton();
		$("#categoryName").val(CAT_ID[id]);
		$.getJSON( "standards/"+CAT_ID[id]+".json").done(function( json ) {
		  	printUnit(json);
		  	makeFactors(json);
		  	sel=json["selected"];
		  	tint(sel);
		  	$("#li"+sel).addClass("selected");
		  	$(".selected .val").html($("#entry").val())
		  	convert();
		  }).fail(function( jqxhr, textStatus, error ) {var err = textStatus + ", " + error;console.log( "Request Failed: " + err );
		});
	},100);
	// clearInterval();
}






// TECLADO
function showKeys(){
	$.get("js/keys.html", function( keys_txt ) {
    	$("#units").append(keys_txt);
	var h = ($( window ).height());
	var w = ($( window ).width());
	$("#keyboard").css({
		"display":"block",
		"position":"fixed",
		"width": w,
		"height": h*KEYBOARD_H,
		// "bottom": -h*0.48,
		"bottom":-h*(KEYBOARD_H),
		"background": "#23202B"
	});
	console.log(-h*KEYBOARD_H*0.2);
	// screen
	$("#screen p, #screen span").css({
		"line-height": h*KEYBOARD_H*0.20+"px",
	});
	//KEYS SIZE
	$(".key").css({
		"height":h*KEYBOARD_H*0.80*0.20,
		"line-height":h*KEYBOARD_H*0.80*0.20+"px",
	});
	//SCREEN VAL
	$("#screen p").html($("#entry").val());
	//COLOR
	$("#keyboard #operators").addClass("txt-"+color);
	$("#op_eq").addClass("bg-"+color);
	//op_eq default behavior
	$("#op_eq").attr("onclick","byeKeys()");
	//KEYS CLICK
	$(".key").click(function($this) {
		defineEvent($this);
	});
	// LAST STEP
	$("#keyboard").animate({"bottom":"0px"},300);
	}, 'html'); 
}



// CAMBIO DE LI

function selectLI(id){
	tint(id);
	var clear=$(".selected")[0].id;
	
	$("#"+clear).removeClass("selected");
	$("#li"+id).addClass('selected');

	$(".val").html(0);
	$(".selected .val").html($("#entry").val());
	convert();
}



