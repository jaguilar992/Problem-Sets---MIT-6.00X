# -*- coding: utf-8 -*-

import math

class RectVector(object):
	"""docstring for Vector"""
	def __init__(self, x, y):
		self.x=x
		self.y=y

	def __str__(self):
		return "{"+str(self.x)+","+str(self.y)+"}"

	def getComponents(self):
		return [self.x,self.y]

	def getNorm(self):
		return math.sqrt(self.x**2+self.y**2)
	def getAngle(self):
		angle=math.atan2(self.y,self.x)*180/math.pi
		if angle<0:
			return angle +360
		else:
			return angle
	def __add__(self,v2):
		v2x=v2.x
		v2y=v2.y
		Ex=self.x+v2x
		Ey=self.y+v2y
		return RectVector(Ex,Ey)

	def __rmul__(self,num):
		Ex=num*self.x
		Ey=num*self.y
		return self.returnPolar(Ex,Ey)


