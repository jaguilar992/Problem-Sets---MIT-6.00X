# -*- coding: utf-8 -*-

import telebot 
from telebot import types 
import time
# sys.setdefaultencoding() does not exist, here!
import sys
reload(sys)  # Reload does the trick!
sys.setdefaultencoding('UTF8')

from RectVector import *
from PolarVector import *
from Arrow import *
from vectlibrary import *
from Kinematics import *

TOKEN = '192905357:AAE6EWNwivLEYUsjwWbzWBF6PXp1mq-3To8' # Nuestro tokken del bot (el que @BotFather nos dió).
bot = telebot.TeleBot(TOKEN)
##############################################Listener
def listener(messages):
    for m in messages:
        if m.content_type == 'text':
            cid = m.chat.id
            user = m.from_user.id
            print "[" + str(user)+"@"+str(cid) + "]: " + m.text
            h=time.strftime("%H:%M:%S")
            d=time.strftime("%d/%m/%y")
            db=open("msg.dat","a")
            db.write("[" + str(user)+"@"+str(cid) + "]"+"["+d+", "+h+"]: " + m.text+"\n")
            db.close()

bot.set_update_listener(listener) 

############################################# #Funciones Basicas

@bot.message_handler(commands=['start','help'])
def command_start(m):
    cid = m.chat.id
    if m.text=="/start":
        bot.send_message( cid, "Iniciando...")


@bot.message_handler(commands=['about']) 
def command_about(m): 
    cid = m.chat.id 
    bot.send_message( cid, "Antonio Aguilar - 2016")

@bot.message_handler(commands=['spy']) 
def command_spy(m): 
    cid = m.chat.id
    text= m.text

    if text=="/spy":
        db=open("msg.dat","r")
        lines=db.readlines()
        for line in lines:
            bot.send_message(cid,str(line).decode("utf-8"))


##################################################################### Vectores

# sum: Suma de vectores en coordenadas rectangulares, regresa un vcetor y la grafica del poligono para la suma
@bot.message_handler(commands=['sum'])
def command_sum(m):
    cid = m.chat.id
    text= m.text
    if text=="/sum":
        bot.send_message( cid, "<strong>Función /sum</strong>:" +
            "\nToma un arreglo de vectores de la forma {x,y} y devuelve la gráfica y suma de los mismos"+
            "\n Ejemplo: <code>/sum [{24,-18},{-4.4,6}]</code>",parse_mode="HTML")
    else:
        vects_text=extract_from_array(text)
        [vectors,flag]=vect_from_text(vects_text)

        if flag==1:
            r=RectVector(0,0)
            for vect in vectors:
                r+=vect
            # bot.send_message(cid,str(r))
            photo=open(graphRectVectSum(vectors,r),"rb")
            bot.send_photo(cid,photo,caption="R= "+str(r))                     
        else:
            bot.send_message(cid, "Error de sintaxis en <code>/sum</code>...",parse_mode="HTML")
            bot.send_message(cid, "\n Ejemplo: <code>/sum [{24,-18},{-4.4,6}]</code>",parse_mode="HTML")

# Fin sum

# graphs Toma un array y devuelve la gráfica con los vectores iniciando en el origen
@bot.message_handler(commands=['graph',"plot"])
def command_graph(m):
    cid = m.chat.id
    text= m.text
    opts=['/graph','/plot']
    if text in opts:
        index=opts.index(text)
        var_text=opts[index]
        bot.send_message( cid, "<strong>Función "+var_text+"</strong>:" +
            "\nToma un vector {x,y} y devuelve la gráfica del mismo"+
            "\n Ejemplo: <code>"+var_text+" {24,-18}</code>"+
            "\n\nToma un arreglo de vectores de la forma {x,y} y devuelve la gráfica."+
            "\n Ejemplo: <code>"+var_text+" [{24,-18},{-4.4,6}]</code>"
            ,parse_mode="HTML")
    else:
        vects_text=extract_from_array(text)
        [vectors,flag]=vect_from_text(vects_text)

        if flag==1:
            photo=open(graphRectVectArray(vectors),"rb")
            bot.send_photo(cid,photo,caption=text)                   
        else:
            bot.send_message(cid, "Error de sintaxis en <code>/graph</code>...",parse_mode="HTML")
            bot.send_message( cid, "\n Ejemplo: <code>/graph {24,-18}</code>"+
                "\n\n Ejemplo: <code>/graph [{24,-18},{-4.4,6}]</code>"
                ,parse_mode="HTML")

# fin graphs

#polar: Toma un vector en coordenadas rectangulares y lo devuelve en coordenadas polares
@bot.message_handler(commands=['polar'])
def command_polar(m):
    cid = m.chat.id
    text= m.text
    if text in ['/polar']:
        bot.send_message( cid, "<strong>Función /polar</strong>:" +
            "\nToma un vector {x,y} y devuelve un vector en coordenadas polares de la forma (r,"+"θ".decode("utf-8")+")"+
            "\n Ejemplo: <code>/polar {24,-18}</code>"
            ,parse_mode="HTML")
    else:
        # print text
        vects_text=extract_from_array(text)
        [vectors,flag]=vect_from_text(vects_text)

        if flag==1:
            vector=vectors[0]
            r=float("%.3f" % vector.getNorm())
            theta=float("{0:.2f}".format(vector.getAngle()))
            polar=PolarVector(r,theta)
            bot.send_message(cid,"="+str(polar))
        else:
            bot.send_message(cid, "Error de sintaxis en <code>/polar</code>...",parse_mode="HTML")
            bot.send_message(cid, "\n Ejemplo: <code>/polar {24,-18}</code>", parse_mode="HTML")
# Fin polar


#rect: Toma un vector en coordenadas polares y lo devuelve en coordenadas rectangulares
@bot.message_handler(commands=['rect'])
def command_rect(m):
    cid = m.chat.id
    text= m.text
    if text in ['/rect']:
        bot.send_message( cid, "<strong>Función /rect</strong>:" +
            "\nToma un vector {r,"+"θ".decode("utf-8")+"} y devuelve un vector en coordenadas rectangulares de la forma {x,y}"
            "\n Ejemplo: <code>/rect {4,180}</code>"
            ,parse_mode="HTML")
    else:
        # print text
        vects_text=extract_from_array(text)
        [vectors,flag]=vect_from_text2(vects_text)

        if flag==1:
            vector=vectors[0]
            [x,y]=vector.getComponents()
            x=float("%.4f" % x)
            y=float("%.4f" % y)
            rect=RectVector(x,y)
            bot.send_message(cid,"="+str(rect))

        else:
            bot.send_message(cid, "Error de sintaxis en <code>/rect</code>...",parse_mode="HTML")
            bot.send_message(cid, "\n Ejemplo: <code>/rect {4,180}</code>", parse_mode="HTML")
# Fin rect


################################################################      Kinematics

# Realiza una aninacion de objeto en MRU
@bot.message_handler(commands=['mru'])
def command_rect(m):
    cid = m.chat.id
    text= m.text
    if text in ['/mru']:
        bot.send_message( cid, "<strong>Función /mru</strong>:" +
            "\nToma un conjunto de datos {v0,t} ,(Unidades del SI), de un objeto en MRU y devuelve una tabla con las coordenadas del objeto."
            "\n Ejemplo: <code>/mru {10,10}]</code>"
            ,parse_mode="HTML")
    else:
        # print text
        vects_text=extract_from_array(text)
        [vectors,flag]=vect_from_text(vects_text)

        if flag==1 and len(vectors)==1:
             
            [v0,t]=vectors[0].getComponents()
            v0=float("%.4f" % v0)
            t=float("%.4f" % t)
            if v0>=0 and t>=0:
                photo=open(RunObjectMRU(v0,t),"rb")
                bot.send_photo(cid,photo,caption=text)

        else:
            bot.send_message(cid, "Error de sintaxis en <code>/mru</code>...",parse_mode="HTML")
            bot.send_message(cid, "\n Ejemplo: <code>/mru {10,10}</code>", parse_mode="HTML")
# Fin mru



# Realiza una aninacion de objeto en caída libre
@bot.message_handler(commands=['freefall'])
def command_rect(m):
    cid = m.chat.id
    text= m.text
    if text in ['/freefall']:
        bot.send_message( cid, "<strong>Función /freefall</strong>:" +
            "\nToma un conjunto de datos [{x0,y0},{v0,g}] ,(Unidades del SI), de un objeto en caída libre y devuelve una tabla con las coordenadas en el tiempo de caída del objeto."
            "\n Ejemplo: <code>/freefall [{0,10},{0,9.8}]</code>"
            ,parse_mode="HTML")
    else:
        # print text
        vects_text=extract_from_array(text)
        [vectors,flag]=vect_from_text(vects_text)

        if flag==1 and len(vectors)==2:
            [pos0,mov_details]=vectors[:2]
            [x0,y0]=pos0.getComponents()
            [v0,g]=mov_details.getComponents()
            
            x0=float("%.4f" % x0)
            y0=float("%.4f" % y0)
            v0=float("%.4f" % v0)
            g=float("%.4f" % g)
            if y0>=0 and g!=0:
                photo=open(RunObjectfalling(x0,y0,v0,g),"rb")
                bot.send_photo(cid,photo,caption=text)

        else:
            bot.send_message(cid, "Error de sintaxis en <code>/freefall</code>...",parse_mode="HTML")
            bot.send_message(cid, "\n Ejemplo: <code>/freefall [{0,10},{0,9.8}]</code>", parse_mode="HTML")
# Fin freefall




#Keep Running
bot.polling(none_stop=True)

