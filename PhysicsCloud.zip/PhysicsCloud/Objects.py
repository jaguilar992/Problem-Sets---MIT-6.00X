from math import sqrt
def solve_quadEQN(a,b,c):
	disc=b**2-4*a*c
	x1=(-b+sqrt(disc))/float(2*a)
	x2=(-b-sqrt(disc))/float(2*a)
	return max(x1,x2)



class mru_object(object):
	def __init__(self, v_o):
		self.v_o=v_o
		
	def getMov_at(self,t):
		x=self.v_o*t
		y=0
		v=self.v_o
		return MovEstOneD(x,y,v)



class free_falling_obj(object):
	def __init__(self, x_o,y_o,v_o,g):
		self.v_o=v_o
		self.x_o=x_o
		self.y_o=y_o
		self.g=g

	def getMov_at(self,t):
		x=self.x_o
		y=self.y_o+self.v_o*t-0.5*self.g*t**2
		y=float("{0:.10f}".format(y))
		v=self.v_o-self.g*t
		return MovEstOneD(x,y,v)

	def getT(self):
		return solve_quadEQN(-0.5*self.g,self.v_o,self.y_o)

	def getH(self):
		if (self.v_o < 0):
			return self.y_o 
		else:
			return ((self.v_o)**2/float(2*self.g))+self.y_o


class MovEstOneD(object):
	"""docstring for MovEstOneD"""
	def __init__(self, x,y,v):
		self.x = x
		self.y = y
		self.v = v

	def __str__(self):
		return "("+str(self.x)+","+str(self.y)+")"

	def get_coordX(self):
		return self.x

	def get_coordY(self):
		return self.y

	def getV(self):
		return self.v


class MovEstTwoD(object):
	"""docstring for MovEstTwoD"""
	def __init__(self, x,y,vx,vy):
		self.x = x
		self.y = y
		self.vx = vx
		self.vy = vy


	def __str__(self):
		return "("+str(self.x)+","+str(self.y)+")"

	def get_coordX(self):
		return self.x

	def get_coordY(self):
		return self.y

	def getVx(self):
		return self.vx

	def getVy(self):
		return self.vy



