# -*- coding: utf-8 -*-
from RectVector import *
from random import sample
from string import join
from matplotlib import patches
import matplotlib.pyplot as plt
choice="0123456789ABCDEF"



def graphRectVectSum(vectors,r):
	# print vectors
	allX_values=0
	allY_values=0
	[rx,ry]=r.getComponents()
	allX_values+=abs(rx)
	allY_values+=abs(ry)
	for vect in vectors:
		allX_values+=abs(vect.getComponents()[0])
		allY_values+=abs(vect.getComponents()[1])

	max_val=max(allX_values/float(2),allY_values/float(2))
	
	plt.figure()
	ax = plt.axes()

	color="#"+join(sample(choice,6),"")
	plt.title("|R| = "+str(r.getNorm())+"          "+'ö = '.decode("utf-8")+str(r.getAngle()),color=color)
	
	if rx!=0 and ry!=0:
		ax.arrow(0, 0, rx, ry, head_width=max_val/float(40), head_length=2*max_val/float(30),length_includes_head=True, width=float(max_val)/100,color=color)

	ax.text(3*rx/float(4), ry/float(2), "R", fontsize=10,color=color,fontweight='bold') #LETRA
	ax.set_xlim([-1.1*max_val,1.1*max_val])
	ax.set_ylim([-1.1*max_val,1.1*max_val])
	r=RectVector(0,0)
	ax = plt.axes()
	plt.axhline(0, color='black')
	plt.axvline(0, color='black')
	ax.grid(True)
	lastX=0
	lastY=0
	last=1.1*max_val
	i=1
	for vect in vectors:
		color="#"+join(sample(choice,6),"")
		[x,y]=vect.getComponents()
		if x!=0  or y!=0:
			ax.arrow(lastX, lastY, x, y, head_width=max_val/float(40), head_length=2*max_val/float(30),length_includes_head=True, width=float(max_val)/100,color=color)
			ax.text(1.2*max_val, last, str(i), fontsize=14,color=color,fontweight="bold") #LETRA
			last-=max_val/8
			i+=1
			lastX+=x
			lastY+=y
		else:
			continue

	fileID=join(sample(choice,6),"")	
	plt.savefig(fileID+".png")	
	return fileID+".png"
		

def graphRectVectArray(vectors):
	# print vectors
	all_values=[]
	for vect in vectors:
		all_values+=[abs(vect.getComponents()[0])]
		all_values+=[abs(vect.getComponents()[1])]

	max_val=max(all_values)
	
	plt.figure()
	ax = plt.axes()

	ax.set_xlim([-1.1*max_val,1.1*max_val])
	ax.set_ylim([-1.1*max_val,1.1*max_val])
	ax = plt.axes()
	plt.axhline(0, color='black')
	plt.axvline(0, color='black')
	ax.grid(True)
	last=1.1*max_val
	i=1
	for vect in vectors:
		color="#"+join(sample(choice,6),"")
		[x,y]=vect.getComponents()
		if x!=0  or y!=0:
			ax.arrow(0, 0, x, y, head_width=max_val/float(40), head_length=2*max_val/float(30),length_includes_head=True, width=float(max_val)/100,color=color)
			ax.text(1.2*max_val, last, str(i), fontsize=14,color=color,fontweight="bold") #LETRA
			last-=max_val/8
			i+=1
		else:
			continue
	fileID=join(sample(choice,6),"")	
	plt.savefig(fileID+".png")	
	return fileID+".png"


# vects=[RectVector(10,0),RectVector(0,-5),RectVector(4,8)]
# r=RectVector(0,0)
# for vect in vects:
# 	r+=vect
# print graphRectVectSum(vects,r)