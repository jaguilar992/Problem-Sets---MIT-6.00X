def deVectorize(result):
    if len(result)==2:
        x=float(result[0])
        y=float(result[1])
    elif len(result)==4:
        x=float(result[0]+result[1])
        y=float(result[2]+result[3])
    else:
        if "." in result[0]:
            x=float(result[0]+result[1])
            y=float(result[2])
        else:
            x=float(result[0])
            y=float(result[1]+result[2])
    return (x,y)