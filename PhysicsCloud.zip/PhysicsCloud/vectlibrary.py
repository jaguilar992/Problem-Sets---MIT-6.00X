import re
from RectVector import *
from PolarVector import *
def extract_from_array(text):
    if len(re.findall("(\{[\S]+\})",text)) :#and ("}{" in text or "},{" in text):
        text=text.replace(" ","")
        text=text.replace("}{","},{")
        vects=re.findall("(\{[\S]+\})",text)[0].split("},{")
    else:
        vects=[]
    new_vects=[]
    for i in range(0,len(vects)):
        if "{" in vects[i]: this_vect=vects[i].replace("{","")
        if "}" in vects[i]: this_vect=vects[i].replace("}","")
        this_vect="{"+vects[i]+"}"
        if len(this_vect.split(","))==2:
            new_vects+=[this_vect]
    return new_vects


def splitVector(text):
    intREGEXP="(-?\d+\.?)"
    result=re.findall(intREGEXP,text)
    return result

def vectorize(text):
    result=splitVector(text)
    if len(result)==2:
        x=float(result[0])
        y=float(result[1])
    elif len(result)==4:
        x=float(result[0]+result[1])
        y=float(result[2]+result[3])
    elif len(result)==3 and not (("." in result[1]) and ("." in result[2])):
        if "." in result[0]:
            x=float(result[0]+result[1])
            y=float(result[2])
        else:
            x=float(result[0])
            y=float(result[1]+result[2])
    else:
        x="A"
        y="A"
    return [x,y]



def vect_from_text(vects_text):
    vects=[]
    flag=0
    for vect_text in vects_text:
        [x,y]=vectorize(vect_text)
        if (x!="A" and y!="A"):
            vect=RectVector(x,y)
            vects+=[vect]
            flag=1
        else:
            flag=0
            break
    return [vects,flag]

def vect_from_text2(vects_text):
    vects=[]
    flag=0
    for vect_text in vects_text:
        [r,theta]=vectorize(vect_text)
        if (r!="A" and theta!="A"):
            vect=PolarVector(r,theta)
            vects+=[vect]
            flag=1
        else:
            flag=0
            break
    return [vects,flag]


# a=extract_from_array("{-1.0,-46{2,2}")
# print a
# print splitVector(a[0])
# print vectorize(a[])
