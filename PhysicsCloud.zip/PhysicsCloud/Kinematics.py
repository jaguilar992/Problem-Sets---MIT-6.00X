from matplotlib import patches
from Objects import *
from random import sample
from string import join
import matplotlib.pyplot as plt
choice="0123456789ABCDEF"


def RunObjectfalling(x0,y0,v0,g):
	color="#"+join(sample(choice,6),"")

	a=free_falling_obj(x0,y0,v0,g)
	T=a.getT()
	h=a.getH()
	t=0
	dt=T/float(18)
	timetable=[]
	while T-t>=0:
		timetable+=[[ 
		 float("{0:.2f}".format(t))  ,  
		 float( "{0:.2f}".format(  a.getMov_at(t).get_coordX() ) ),  
		 float( "{0:.2f}".format(  a.getMov_at(t).get_coordY() ) ),   
		 float( "{0:.2f}".format(  a.getMov_at(t).getV() ) )  
		 ]]
		t+=dt
	
	# return timetable
	plt.figure()
	ax = plt.axes()
	ax.set_xlim([x0-1,x0+1])
	ax.set_ylim([-1,1.5*h])
	ax = plt.axes()
	plt.axhline(0, color='black')
	plt.axvline(0, color='black')
	ax.grid(True)

	for step in timetable:
		plt.plot(step[1],step[2], "ro",color=color)

	col_labels=['t (s)','x (m)','y (m)', "v(m/s)"]
	# the rectangle is where I want to place the table
	the_table = plt.table(cellText=timetable,
	                  colWidths = [0.1]*4,
	                  colLabels=col_labels,
	                  zorder=100,
	                  loc='center right')

	the_table.auto_set_font_size(False)
	the_table.set_fontsize(7)

	T="{0:.2f}".format(T)
	h="{0:.2f}".format(h)
	plt.title("y0="+str(y0)+" m      v0="+str(v0)+" m/s      g="+str(g)+" m/s^2 \nT="+str(T)+" s      maxH="+str(h)+" m",color=color)

	fileID=join(sample(choice,6),"")	
	plt.savefig(fileID+".png")	
	# plt.show()
	return fileID+".png"


def RunObjectMRU(v0,t):
	color="#"+join(sample(choice,6),"")
	b=mru_object(v0)
	i=0
	dt=t/float(18)
	timetable=[]
	while t-i>=0:
		timetable+=[[ 
		 float("{0:.2f}".format(i))  ,  
		 float( "{0:.2f}".format(  b.getMov_at(i).get_coordX() ) ),  
		 float( "{0:.2f}".format(  b.getMov_at(i).get_coordY() ) ),   
		 float( "{0:.2f}".format(  b.getMov_at(i).getV() ) )  
		 ]]
		i+=dt		

	# return timetable
	plt.figure()
	ax = plt.axes()
	ax.set_xlim([-1,v0*t+1])
	ax.set_ylim([-1,10])
	ax = plt.axes()
	plt.axhline(0, color='black')
	plt.axvline(0, color='black')
	ax.grid(True)

	for step in timetable:
		plt.plot(step[1],step[2], "ro",color=color)

	col_labels=['t (s)','x (m)','y (m)', "v(m/s)"]
	# the rectangle is where I want to place the table
	the_table = plt.table(cellText=timetable,
	                  colWidths = [0.1]*4,
	                  colLabels=col_labels,
	                  zorder=100,
	                  loc='center right')

	the_table.auto_set_font_size(False)
	the_table.set_fontsize(7)

	# T="{0:.2f}".format(i)
	# h="{0:.2f}".format(h)
	# plt.title("y0="+str(y0)+" m      v0="+str(v0)+" m/s      g="+str(g)+" m/s^2 \nT="+str(T)+" s      maxH="+str(h)+" m",color=color)

	fileID=join(sample(choice,6),"")	
	plt.savefig(fileID+".png")	
	# plt.show()
	return fileID+".png"


