# -*- coding: utf-8 -*-
import math

class PolarVector(object):
	"""docstring for Vector"""
	def __init__(self, module, angle):
		self.module=abs(module)
		self.angle=angle*math.pi/180
		self.x=self.getComponents()[0]
		self.y=self.getComponents()[1]

	def __str__(self):
		return "{"+str(self.module)+" ; "+str(self.angle*180/math.pi)+" grados}"

	def getComponents(self):
		return[self.module*math.cos(self.angle), self.module*math.sin(self.angle)]

	def returnPolar(self,Ex, Ey):
		module=math.sqrt(Ex**2+Ey**2)
		angle= math.atan2(Ey,Ex)*180/math.pi
		if angle<0:
			angle+=360
		return PolarVector(module ,angle)

	def __add__(self,v2):
		v2x=v2.x
		v2y=v2.y
		Ex=self.x+v2x
		Ey=self.y+v2y
		return self.returnPolar(Ex,Ey)

	def __rmul__(self,num):
		Ex=num*self.x
		Ey=num*self.y
		return self.returnPolar(Ex,Ey)


